var s="./assets/zhi_.9050a50d.svg";export{s as _};
