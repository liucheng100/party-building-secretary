var s="./assets/zhi_.334ccad5.svg";export{s as _};
